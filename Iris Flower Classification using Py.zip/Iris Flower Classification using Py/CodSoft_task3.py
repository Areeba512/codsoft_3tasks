import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Loading  iris dataset from pc
file = r"C:\Users\Hp\Desktop\IRIS.csv"
irisdf = pd.read_csv(file)

a = irisdf.drop(columns=["species"]).values 
b = irisdf["species"].values 

# Spliting iris dataset into training and testing parts
a_train, a_test, b_train, b_test = train_test_split(a, b, test_size=0.2, random_state=42)

scaler = StandardScaler()
a_train_scaled = scaler.fit_transform(a_train)
a_test_scaled = scaler.transform(a_test)

# using Support Vector Machine (SVM) classifier
svm_model = SVC(kernel='rbf', C=1.0, gamma='scale', random_state=42)
svm_model.fit(a_train_scaled, b_train)

# Predict the labels of test data
b_pred = svm_model.predict(a_test_scaled)

# Calculate accuracy
accuracy = accuracy_score(b_test, b_pred)
print("Accuracy:", accuracy)
# Classification report
print("\nClassification Report:")
print(classification_report(b_test, b_pred, target_names=np.unique(b)))

# Confusion Matrix visualization
cm = confusion_matrix(b_test, b_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, cmap='viridis', fmt='g', xticklabels=irisdf['species'].unique(), yticklabels=irisdf['species'].unique())
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()
# Scatter plot for visualization of Iris dataset
sns.pairplot(irisdf, hue='species', palette='Dark2')
plt.show()
